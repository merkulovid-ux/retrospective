# Codex Tasks (Research Preview)

— FE-аудит и DIFF; — Автотесты; — Медиа. См. v2 пак.