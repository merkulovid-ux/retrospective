import OpenAI from "openai";
import fs from "node:fs";
const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
async function main() {
  const file = await client.files.create({ file: fs.createReadStream("site/index.html"), purpose: "assistants" });
  const vectorStore = await client.vectorStores.create({ name: "agilta-landing" });
  await client.vectorStores.fileBatches.uploadAndPoll(vectorStore.id, { files: [file.id] });
  const assistant = await client.assistants.create({
    name: "Agilta Landing FE Assistant",
    instructions: ["Ты — FE/UX ассистент...", "DIFF-патчи к site/index.html"].join("\n"),
    model: "gpt-4.1",
    tools: [{ type: "code_interpreter" }, { type: "file_search", vector_store_ids: [vectorStore.id] }]
  });
  console.log("Assistant:", assistant.id);
}
main().catch((e)=>{ console.error(e); process.exit(1); });