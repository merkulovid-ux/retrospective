Cursor: Settings→Models→API Keys; GPT-4.1; Ctrl+T для новых чатов.
